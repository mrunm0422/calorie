<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width">

	<title>Welcome to our page!!</title>
	<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <div class="menu_bar">
  